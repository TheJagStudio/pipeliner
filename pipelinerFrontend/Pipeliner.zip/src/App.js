import React, { useCallback } from 'react';
import ReactFlow, {
	MiniMap,
	Controls,
	Background,
	useNodesState,
	useEdgesState,
	addEdge,
} from 'reactflow';

import 'reactflow/dist/style.css';
import CustomNode from './Components/CustomNode';

const nodeTypes = {
	custom: CustomNode,
};

const initNodes = [
	{
		id: '1',
		type: 'custom',
		data: { name: 'Jane Doe', job: 'CEO', emoji: '😎' },
		position: { x: 0, y: 50 },
	},
	{
		id: '2',
		type: 'custom',
		data: { name: 'Tyler Weary', job: 'Designer', emoji: '🤓' },
		position: { x: -200, y: 200 },
	},
	{
		id: '3',
		type: 'custom',
		data: { name: 'Kristi Price', job: 'Developer', emoji: '🤩' },
		position: { x: 200, y: 200 },
	},
];

const initEdges = [
	{
		id: 'e1-2',
		source: '1',
		target: '2',
	},
	{
		id: 'e1-3',
		source: '1',
		target: '3',
	},
];
export default function App() {
	const [nodes, setNodes, onNodesChange] = useNodesState(initNodes);
	const [edges, setEdges, onEdgesChange] = useEdgesState(initEdges);

	const onConnect = useCallback((params) => setEdges((eds) => addEdge(params, eds)), []);

	return (
		<div className="flex flex-col bg-gray-400 h-screen">
			<header className="flex justify-between items-center px-4 py-2 bg-gray-800">
				<h1 className="text-2xl text-white font-bold capitalize font-mono">PIPELINER</h1>
				<div className="flex items-center">
					<button className="bg-gray-700 hover:bg-gray-500 transition-all duration-300 outline outline-offset-2 outline-0 focus:outline-2 outline-gray-700 text-white px-4 py-2 rounded-md">New</button>
					<button className="bg-gray-700 hover:bg-gray-500 transition-all duration-300 outline outline-offset-2 outline-0 focus:outline-2 outline-gray-700 text-white px-4 py-2 rounded-md ml-2">Open</button>
					<button className="bg-gray-700 hover:bg-gray-500 transition-all duration-300 outline outline-offset-2 outline-0 focus:outline-2 outline-gray-700 text-white px-4 py-2 rounded-md ml-2">Save</button>
					<button className="bg-gray-700 hover:bg-gray-500 transition-all duration-300 outline outline-offset-2 outline-0 focus:outline-2 outline-gray-700 text-white px-4 py-2 rounded-md ml-2">Save As</button>
				</div>
			</header>
			<div className="flex px-2 gap-x-2 noScroll overflow-x-scroll items-center h-fit w-full mt-2 drop-shadow-lg">
				<h1 className="text-xl text-white bg-gray-700 hover:bg-gray-600 transition-all duration-300 rounded-full px-3 py-1 font-mono">Hello&nbsp;Moto</h1>
				<h1 className="text-xl text-white bg-gray-700 hover:bg-gray-600 transition-all duration-300 rounded-full px-3 py-1 font-mono">Hello&nbsp;Moto</h1>
				<h1 className="text-xl text-white bg-gray-700 hover:bg-gray-600 transition-all duration-300 rounded-full px-3 py-1 font-mono">Hello&nbsp;Moto</h1>
				<h1 className="text-xl text-white bg-gray-700 hover:bg-gray-600 transition-all duration-300 rounded-full px-3 py-1 font-mono">Hello&nbsp;Moto</h1>
				<h1 className="text-xl text-white bg-gray-700 hover:bg-gray-600 transition-all duration-300 rounded-full px-3 py-1 font-mono">Hello&nbsp;Moto</h1>
				<h1 className="text-xl text-white bg-gray-700 hover:bg-gray-600 transition-all duration-300 rounded-full px-3 py-1 font-mono">Hello&nbsp;Moto</h1>
				<h1 className="text-xl text-white bg-gray-700 hover:bg-gray-600 transition-all duration-300 rounded-full px-3 py-1 font-mono">Hello&nbsp;Moto</h1>
			</div>
			<div className=" w-full h-full rounded-lg p-2">
				<div className="border-2 border-white/75 overflow-hidden drop-shadow-lg  w-full h-full rounded-xl ">
				<ReactFlow
					nodes={nodes}
					edges={edges}
					onNodesChange={onNodesChange}
					onEdgesChange={onEdgesChange}
					onConnect={onConnect}
					nodeTypes={nodeTypes}
					fitView
					>
					<MiniMap />
					<Controls />
					<Background variant="dots" gap={12} size={2} />
				</ReactFlow>
				</div>
			</div>
		</div>
	);
}