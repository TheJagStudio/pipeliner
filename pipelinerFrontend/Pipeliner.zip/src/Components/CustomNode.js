import React, { memo } from 'react';
import { Handle, Position } from 'reactflow';

function CustomNode({ data }) {
    return (
        <div className="shadow-md h-fit w-48 rounded-md bg-white border border-gray-800">
            <div className='px-2 py-1 w-full h-fit flex gap-2 justify-between items-center'>
                <div className='flex gap-1 justify-between items-center'>
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="currentColor" class="bi bi-ui-checks-grid" viewBox="0 0 16 16">
                        <path d="M2 10h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1v-3a1 1 0 0 1 1-1zm9-9h3a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zm0 9a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-3zm0-10a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2h-3zM2 9a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h3a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H2zm7 2a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-3a2 2 0 0 1-2-2v-3zM0 2a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V2zm5.354.854a.5.5 0 1 0-.708-.708L3 3.793l-.646-.647a.5.5 0 1 0-.708.708l1 1a.5.5 0 0 0 .708 0l2-2z"/>
                    </svg>
                    <p className='text-sm font-mono'>Dataset</p>
                </div>
                <div className='border border-stone-400 px-1 rounded-full'>
                    <p className='text-xs font-mono'>490</p>
                </div>
            </div>
            <hr className='border-stone-400'/>
            <div className='grid grid-cols-4 gap-[1px] p-1'>
                <img src={"https://source.unsplash.com/featured/300x300"} alt={""} className='col-span-1 h-auto w-full rounded-l-md'/>
                <img src={"https://source.unsplash.com/featured/300x300"} alt={""} className='col-span-1 h-auto w-full'/>
                <img src={"https://source.unsplash.com/featured/300x300"} alt={""} className='col-span-1 h-auto w-full'/>
                <img src={"https://source.unsplash.com/featured/300x300"} alt={""} className='col-span-1 h-auto w-full rounded-r-md'/>
            </div>
            <p className='px-1 text-xs font-mono font-thin opacity-90 w-48 leading-none'>Recorded from camera 3 and used in production</p>
            <div className='grid grid-cols-3 gap-1 p-1'>
                <div className='bg-gray-200 rounded-md py-2'>
                    <p className='text-[10px] font-bold font-mono leading-none text-center'>2313</p>
                    <p className='text-[8px] font-mono leading-none text-center'>items</p>
                </div>
                <div className='bg-gray-200 rounded-md py-2'>
                    <p className='text-[10px] font-bold font-mono leading-none text-center'>21K</p>
                    <p className='text-[8px] font-mono leading-none text-center'>Completed</p>
                </div>
                <div className='bg-gray-200 rounded-md py-2'>
                    <p className='text-[10px] font-bold font-mono leading-none text-center'>223</p>
                    <p className='text-[8px] font-mono leading-none text-center'>In Progress</p>
                </div>
            </div>
            <div className='p-1 pb-2 flex gap-1 justify-between items-center'>
                <div className='bg-gray-200 h-1.5 w-full rounded-full relative'>
                    <div className='absolute top-0 left-0 h-full w-[60%] bg-gray-800 rounded-full'></div>
                </div>
                <p className='text-[10px] font-mono leading-none text-center'> 60% </p>
            </div>
            <Handle type="target" position={Position.Top} className="w-16 rounded-sm border-none bg-gray-800" />
            <Handle type="source" position={Position.Bottom} className="w-16 rounded-sm border-none bg-gray-800" />
        </div>
    );
}

export default memo(CustomNode);